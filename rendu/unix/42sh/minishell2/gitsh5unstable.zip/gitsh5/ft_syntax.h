/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_syntax.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/05 20:03:28 by tseguier          #+#    #+#             */
/*   Updated: 2014/03/18 08:09:23 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_SYNTAX_H
# define FT_SYNTAX_H
# include "ft_word.h"
# include "libft.h"
/*
** Current syntax parameters.
*/
# define T_SYNTAXTAB_CUR ft_syntaxtab_sh
# define NB_OPSTR 4
# define NB_SEPSTR 5

/*
** Current syntax elements.
*/
# define T_OP_LREDIR "<"
# define T_OP_RREDIR ">"
# define T_OP_LLREDIR "<<"
# define T_OP_RRREDIR ">>"
# define T_SEP_OR "||"
# define T_SEP_AND "&&"
# define T_OP_PIPE "|"
# define T_SEP_SEMICOL ";"
# define T_SEP_NL "\n"
/*
** //remplacer par sep non term dan t_syntax->sepdict
*/
# define T_SEP_CHAR ' '

typedef struct		s_op
{
	char	*label;
	size_t	len;
	int		nbops;
	int		prior;
}					t_op;

typedef struct		s_sep
{
	char	*label;
	size_t	len;
	t_bool	term;
	int		prior;
}					t_sep;

typedef struct		s_syntax
{
	t_op		opdict[NB_OPSTR + 1];
	t_sep		sepdict[NB_SEPSTR + 1];
}					t_syntax;

extern const t_syntax		ft_syntaxtab_sh;

#endif /* !FT_SYNTAX_H */
