/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_builtins.h                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/27 23:53:41 by tseguier          #+#    #+#             */
/*   Updated: 2014/02/06 23:10:10 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_BUILTINS_H
# define FT_BUILTINS_H

int		ft_env(char **env);

char	*ft_getenv(const char *name, char **env);

int		ft_cd(const char *path, char ***env);

int		ft_setenv(char *name, char *val, int over, char ***env);

int		ft_unsetenv(const char *name, char **env);

#endif /* !FT_BUILTINS_H */

