/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lexflush.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/03/19 04:52:26 by tseguier          #+#    #+#             */
/*   Updated: 2014/03/19 04:53:11 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include "ft_lexer.h"
#include "ft_syntax.h"

//prendre le sep trouv2 en param
int		ft_lexflush_opstack(t_lexer lex)
{
	t_word		tmpw;

	while (ft_ldcdsize(lex->opstack))
	{
		tmpw = (t_word)ft_ldcdpop_back(lex->opstack);
		if (!tmpw || (-1 == ft_ldcdpush_back(lex->wordlist, tmpw, S_WORD_SIZE)))
			return (-1);
	}
	ft_ldcdpush_back(lex->wordlist, ft_wordnew(&(lex->syntax.sepdict[3]), t_word_sep), sizeof(struct s_word));
	return (0);
}

