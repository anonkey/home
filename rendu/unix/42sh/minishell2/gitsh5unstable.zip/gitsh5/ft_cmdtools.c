/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_cmdtools.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/29 07:33:15 by tseguier          #+#    #+#             */
/*   Updated: 2014/02/06 03:05:22 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <sys/wait.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
#include "libft.h"
#include "ft_cmd.h"
#include "ft_error.h"
#include "ft_builtins.h"
#include "ft_sighandler.h"
#include "ft_builtins_exec.h"

extern	sig_atomic_t	actson;


int		ft_cmdfindpath(t_cmd cmd, char **env)
{
	int		i;
	char	*path;
	char	*envpath;

	i = 0;
	if ((envpath = ft_getenv("PATH", env)) == NULL)
		return (3);
	while (cmd->abspath == NULL && envpath[i] != 0)
	{
		i += 1 + ft_strcsub(&path, envpath, i, ':');
		ft_strsepjoin(&path, cmd->av[0], "/");
		if (!path)
			return (1);
		if (!ft_cmdsetpath(cmd, path))
			free(path);
	}
	ft_strdel(&envpath);
	return ((cmd->abspath == NULL) ? 3 : 0);
}

int		ft_getabspath(t_cmd cmd)
{
	char	*abspath;

	abspath = getcwd(NULL, 1);
	if (cmd->av[0][1] == '.')
		ft_strsepjoin(&abspath, cmd->av[0], "/");
	else
		abspath = ft_strjoin(abspath, &(cmd->av[0][1]));
	if (!ft_cmdsetpath(cmd, abspath))
		cmd->abspath = NULL;
	ft_strdel(&abspath);
	return (cmd->abspath == NULL);
}

t_cmd	ft_parsecmd(char *strcmd, char ***env)
{
	t_cmd	newcmd;
	int		i;
	char	**av;

	i = 0;
	av = ft_strsplit(strcmd, ' ');
	if (!av)
		return (NULL);
	newcmd = ft_cmdnew(av, env);
	if (!newcmd)
		ft_strtabdel(&av);
	if (av[0] && av[0][0])
	{
		if (av[0][0] == '.' && (av[0][1] == '.' || av[0][1] == '/'))
			newcmd->status = ft_getabspath(newcmd) ? 2 : 0;
		else if (av[0][0] == '/')
			newcmd->status = (ft_cmdsetpath(newcmd, av[0]) == 1) ? 0 : 2;
		else if (0 == (newcmd->status = ft_builtins_get(newcmd)))
			newcmd->abspath = NULL;
		else
			newcmd->status = ft_cmdfindpath(newcmd, *env);
	}
	return (newcmd);
}

int		ft_execcmd(t_cmd cmd)
{
	pid_t	sonpid;
	int		status;

	if (!cmd->abspath)
		return (ft_builtins_run(cmd));
	sonpid = fork();
	actson = sonpid;
	if (sonpid < 0)
		ft_printerror("ft_minishell", NULL, 4, 1);
	else if (sonpid == 0)
	{
		execve(cmd->abspath, cmd->av, *(cmd->env));
		ft_printerror("ft_minishell", cmd->av[0], 7, 1);
	}
	else
	{
		waitpid(sonpid, &status, WUNTRACED);
		if (WIFSTOPPED(status))
			ft_setenv("FGPROC", ft_itoa(sonpid), 1, cmd->env);
		actson = -1;
	}
	return (0);
}

