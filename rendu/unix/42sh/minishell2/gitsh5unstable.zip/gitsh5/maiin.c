/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/29 03:46:58 by tseguier          #+#    #+#             */
/*   Updated: 2014/02/07 01:59:44 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include "ft_lexer.h"
#include "ft_word.h"
#include "ft_cmd.h"
#include "ft_btree.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

void	ft_putvword(void *vword)
{
	if (((t_word)vword)->type == t_word_empty)
		ft_putendl("EMPTY_WORD");
	else if (((t_word)vword)->type == t_word_cmd)
	{
		ft_putstr("Cmd : ");
		ft_putendl(((t_cmd)((t_word)vword)->content)->av[0]);
	}
	else if (((t_word)vword)->type == t_word_op)
	{
		ft_putstr("Op : ");
		ft_putendl(((t_op *)((t_word)vword)->content)->label);
	}
	else if (((t_word)vword)->type == t_word_start)
	{
		ft_putendl((char *)((t_word)vword)->content);
	}
	else
		ft_putendl("ERROR");
}

void	ft_putvstr(void *str)
{
	ft_putendl((char *)str);
}

tree	ft_fill_astree(t_astree tree, t_ldcd contentl)
{
	t_astree		treetmp;

	if (!tree || ft_ldcdsize(contentl) == 0
		|| ((t_word)(tree->content))->type < t_word_op)
		return (NULL);
	treetmp = ft_astreenew(ft_ldcdpop_back(contentl));
	if (((t_word)(tree->content))->type ==  ((t_word)(treetmp->content))->type)
		ft_astree_nodeadd(tree, treetmp, TREE_BRO);
	else
		ft_astree_nodeadd(tree, treetmp, TREE_SON);
	ft_fill_astree(treetmp, contentl);
	if (ft_ldcdsize(contentl) == 0
		|| ((t_word)tree->content)-> type != t_word_op
		|| ((t_op*)((t_word)tree->content))->nbops < 2)
		return ;
	treel = ft_astreenew(ft_ldcdpop_back(contentl));
	ft_astree_nodeadd(tree, treel, 0);
	ft_fill_astree(treel, contentl);
}

int		main(int argc, char **argv)
{
	t_btree		tree;
	t_ldcd		tmplst;
	t_lexer		lex;

	if (argc < 2)
		return (-1);
	lex = ft_lexnew(argv[1]);
	if (0 > ft_lexerize(lex))
		return (-2);
	while (ft_ldcdsize(lex->outlist))
	{
		ft_putendl("");
		ft_putnbr(ft_ldcdsize(lex->outlist));
		ft_putendl("PROG : ");
		tmplst = (t_ldcd)ft_ldcdpop_front(lex->outlist);
		while (ft_ldcdsize(tmplst))
		{
			ft_putvword(ft_ldcdpop_back(tmplst));
		}
	}
		ft_putendl("");
	ft_putendl("LAST PROG : ");
//	while (ft_ldcdsize(lex->wordlist))
//	{
//		ft_putvword(ft_ldcdpop_back(lex->wordlist));
//	}
	tree = ft_btreenew(ft_wordnew(ft_strdup("Start :"), t_word_start), 1);
	if (!tree)
		return (-3);
	ft_fill_btree(tree, lex->wordlist);
	ft_putbtree(tree, &ft_putvword);
	ft_btreedel(&tree, &ft_memdel);
	ft_lexdel(&lex);
	return (0);
}

