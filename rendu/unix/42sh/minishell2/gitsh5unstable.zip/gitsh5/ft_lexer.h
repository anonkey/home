/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lexer.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/29 08:52:57 by tseguier          #+#    #+#             */
/*   Updated: 2014/03/19 04:48:02 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_LEXER_H
# define FT_LEXER_H
# define T_LEX_NBOPS 4
# define S_WORD_SIZE (sizeof(struct s_word))
# include <stdlib.h>
# include "libft.h"
# include "ft_word.h"
# include "ft_cmd.h"
# include "ft_syntax.h"

typedef struct		s_lexer
{
	char		*strin;
	int			strstart;
	t_bool		filename;
	t_cmd		cmdact;
	t_syntax	syntax;
	t_ldcd		opstack;
	t_ldcd		wordlist;
	t_ldcd		arglist;
	int			status;
}					*t_lexer;


t_lexer		ft_lexnew(char *strin);
void		ft_lexdel(t_lexer *lex_p);
int			ft_lexerize(t_lexer lex);

int			ft_lexop_init(t_lexer lex);

int			ft_lexflush_opstack(t_lexer lex);
int			ft_lexadd_actword(t_lexer lex, t_word actw);
int			ft_lexflush_firstop(t_lexer lex);

int			ft_lexnext_filename(t_lexer lex, size_t wlen);

int			ft_word_priorcmp(t_word w1, t_word w2);

#endif /* !FT_LEXER_H */

