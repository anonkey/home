/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lexsep.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/06 00:47:43 by tseguier          #+#    #+#             */
/*   Updated: 2014/03/19 04:52:02 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "libft.h"
#include "ft_lexer.h"
#include "ft_syntax.h"

int		ft_lex_termsep(t_lexer lex, int sepind)
{
	if (!lex || sepind < 0 || sepind >= NB_SEPSTR)
		return (-1);
	lex->strstart += lex->syntax.sepdict[sepind].len;
	ft_lexflush_opstack(lex);
	return (0);
}

int		ft_lexnext_sep(t_lexer lex, int sepind)
{
	t_word		sepw;

	if (!lex || sepind >= NB_SEPSTR || sepind < 0)
		return (-1);
	ft_lexflush_arglist(lex->cmdact, lex->arglist);
	lex->cmdact = NULL;
	if (lex->syntax.sepdict[sepind].term)
		ft_lex_termsep(lex, sepind);
	else
	{
		sepw = ft_wordnew((void *)&(lex->syntax.sepdict[sepind]), t_word_sep);
		if (!sepw)
			return (-2);
		if (ft_lexadd_actword(lex, sepw))
			return (-3);
	}
	lex->strstart += ft_strlen(lex->syntax.sepdict[sepind].label);
	return (0);
}

int		ft_lex_getsep(t_lexer lex, size_t len)
{
	int		i;
	char	*start;
	t_sep	*sepstr;

	i = 0;
	start = lex->strin + lex->strstart + (long)len;
	while (i < NB_SEPSTR)
	{
		sepstr = &(lex->syntax.sepdict[i]);
		if (!strncmp(sepstr->label, start, sepstr->len))
			return (i);
		++i;
	}
	return (-1);
}

t_bool		ft_lex_issep(t_lexer lex, size_t len)
{
	return ((0 <= ft_lex_getsep(lex, len)) ? true : false);
}

