/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sighandler.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/12 00:40:12 by tseguier          #+#    #+#             */
/*   Updated: 2014/02/10 06:16:30 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <signal.h>
#include <stdlib.h>
#include "ft_error.h"
#include "ft_cmd.h"
#include "libft.h"
#include "ft_sighandler.h"

sig_atomic_t	actson;

void	ft_siginit()
{
	signal(SIGINT, &ft_sigint);
	signal(SIGQUIT, &ft_sigint);
	signal(SIGTSTP, &ft_sigtstp);
	actson = -1;
}

void	ft_sigint(int sig)
{
	signal(sig, &ft_sigint);
	if (actson == 0)
		exit(EXIT_SUCCESS);
	else
		ft_putendl(NULL);
	if (actson < 0)
		FT_PUTPROMPT;
}

void	ft_sigtstp(int sig)
{
	signal(sig, &ft_sigtstp);
	ft_putendl(NULL);
	if (actson < 0)
		FT_PUTPROMPT;
}

void	ft_sigcont(int sig)
{
	if (sig)
		signal(SIGTSTP, &ft_sigtstp);
}

