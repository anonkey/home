/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_program.h                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/06 05:30:47 by tseguier          #+#    #+#             */
/*   Updated: 2014/02/06 06:38:24 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PROGRAM_H
# define FT_PROGRAM_H
# include "libft.h"
# include "ft_word.h"

typedef struct		s_program
{
	t_ldcd			wordlist;
	t_word			nextw;
}					*t_program;

t_program	ft_prognew(t_ldcd wordlist);

#endif /* !FT_PROGRAM_H */
