/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_astree.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/03 22:12:07 by tseguier          #+#    #+#             */
/*   Updated: 2014/02/07 06:35:19 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_ASTREE_H
# define FT_ASTREE_H

typedef struct		s_astree
{
	int				flag;
	void			*content;
	struct s_astree	*fath;
	struct s_astree	*bro;
	struct s_astree	*son;
}					*t_astree;

t_astree	ft_astreenew(void *c);

void		ft_astreeflush(t_astree *astree, void (*del)(void **));

void		ft_astreedel(t_astree *astree_p, void (*del)(void **));

int			ft_astree_addson(t_astree tree, t_astree succ);

int			ft_astree_addbro(t_astree tree, t_astree succ);

void		ft_putastree_node(t_astree tree, int depth, void (*putfunc)(void *));

void		ft_putastree(t_astree tree, void (*putfunc)(void *));

#endif /* !FT_ASTREE_H */
