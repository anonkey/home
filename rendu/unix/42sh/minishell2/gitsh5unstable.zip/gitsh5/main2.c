/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/25 18:25:16 by tseguier          #+#    #+#             */
/*   Updated: 2014/01/23 23:37:02 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <signal.h>
#include "libft.h"
#include "ft_sighandler.h"
#include "ft_error.h"
#include "ft_cmd.h"
#include "ft_cmdtools.h"

extern char		**environ;

void	ft_shloop(char **env)
{
	t_cmd	cmd_s;
	char	*cmd;

	while (1)
	{
		FT_PUTPROMPT;
		if (-1 == get_next_line(0, &cmd))
			ft_printerror("ft_minishell", NULL, 8, 1);
		else
		{
		cmd_s = ft_parsecmd(cmd, &env);
		if (!cmd_s)
			ft_printerror("ft_minishell", NULL, 1, 1);
		else if (cmd_s->status)
			ft_printerror("ft_minishell", cmd_s->av[0], cmd_s->status, 1);
		else if (cmd_s->av && cmd_s->av[0])
			ft_execcmd(cmd_s);
		ft_cmddel(&cmd_s);
		ft_strdel(&cmd);
		}
	}
}

int		main(void)
{
	char	**env;
	int		i;

	i = 1;
	env = NULL;
	if (environ)
	{
		env = ft_strtabcpy(environ, 0);
		if (!env)
			ft_printerror("ft_minishell", "Can't generate environement", 1, 1);
		ft_siginit();
	}
	ft_shloop(env);
	return (0);
}

