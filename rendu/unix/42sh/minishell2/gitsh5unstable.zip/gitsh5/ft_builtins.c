/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_builtins.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/27 23:53:41 by tseguier          #+#    #+#             */
/*   Updated: 2014/01/24 00:26:14 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>
#include "libft.h"
#include "ft_error.h"

extern char		**environ;

int		ft_env(char **env)
{
	int		i;

	i = 0;
	while (env[i])
	{
		ft_putendl(env[i]);
		++i;
	}
	return (0);
}

char	*ft_getenv(const char *name, char **env)
{
	int		i;
	size_t	namelen;

	i = 0;
	if (!env || !name)
		return (NULL);
	namelen = ft_strlen(name);
	while (env[i] && ft_strncmp(env[i], name, 4))
		++i;
	return (env[i] ? ft_strdup(env[i] + ft_strlen(name) + 1) : NULL);
}

int		ft_setenv(char *name, char *val, int over, char ***env)
{
	int		i;
	size_t	namelen;
	int		err;

	i = 0;
	if (!name || !env || !*env)
		return ((env && !*env) ? -2 : -1);
	namelen = ft_strlen(name);
	while ((*env)[i] && ft_strncmp((*env)[i], name, namelen))
		++i;
	if (!(*env)[i])
		ft_strtabrealloc(env, 1);
	if (over && (*env)[i])
			ft_strdel(&((*env)[i]));
	if (!(*env)[i])
	{
		if (!((*env)[i] = ft_strjoin(name, "=")))
			return (-3);
	}
	val = val ? val : "";
	if ((*env)[i][namelen + 1])
		err = ft_strsepjoin(&((*env)[i]), val, ":");
	else
		err = ft_strsepjoin(&((*env)[i]), val, "");
	return (err);
}

int		ft_cd(const char *path, char ***env)
{
	char	*temp;

	if (!path)
		path = ft_getenv("HOME", *env);
	if (chdir(path) != 0)
	{
		ft_printerror("cd", path, 2, 1);
		return (-1);
	}
	temp = ft_getenv("PWD", environ);
	ft_setenv("PWD", temp, 1, env);
	ft_strdel(&temp);
	temp = ft_getenv("OLDPWD", environ);
	ft_setenv("OLDPWD", temp, 1, env);
	return (0);
}


int		ft_unsetenv(const char *name, char **env)
{
	int		i;
	size_t	namelen;

	i = 0;
	if (!name)
	{
		ft_putendl_fd("Usage : unsetenv name", 2);
		return (0);
	}
	if (!env || !name)
		return ((!env) ? -2 : -1);
	namelen = ft_strlen(name);
	while (env[i] && ft_strncmp(env[i], name, namelen))
		++i;
	if (!env[i])
		return (-2);
	ft_strdel(&(env[i]));
	while (env[i + 1])
	{
		env[i] = env[i + 1];
		++i;
	}
	return (0);
}

