/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_cmd.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/25 23:43:49 by tseguier          #+#    #+#             */
/*   Updated: 2014/01/23 23:39:34 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_CMD_H
# define FT_CMD_H
# define FT_PUTPROMPT ft_putstr("\033[32;1mAsh -> \033[0m")

typedef struct		s_cmd
{
	char	*abspath;
	char	**av;
	char	***env;
	int		status;
}					*t_cmd;

int		ft_cmdsetpath(t_cmd cmd, char *path);

t_cmd	ft_cmdnew(char **av, char ***env);

void	ft_cmddel(t_cmd *cmd);

#endif /* !FT_CMD_H */

