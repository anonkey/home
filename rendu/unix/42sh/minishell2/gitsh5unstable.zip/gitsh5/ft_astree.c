/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_astree.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/03 22:12:16 by tseguier          #+#    #+#             */
/*   Updated: 2014/02/07 08:26:13 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "ft_astree.h"
#include "libft.h"

t_astree		ft_astreenew(void *c)
{
	t_astree		newastree;

	newastree = (t_astree)ft_memalloc(sizeof(struct s_astree));
	if (!newastree)
		return (NULL);
	newastree->content = c;
	newastree->flag = 0;
	newastree->son = NULL;
	newastree->bro = NULL;
	newastree->fath = NULL;
	return (newastree);
}

void		ft_astreeflush(t_astree *astree_p, void (*del)(void **))
{
	if (!astree_p || !*astree_p)
		return ;
	if (del && ((*astree_p)->content))
		del(&((*astree_p)->content));
	ft_astreeflush(&((*astree_p)->bro), del);
	ft_astreeflush(&((*astree_p)->son), del);
	ft_memdel((void **)astree_p);
}

void		ft_astreedel(t_astree *astree_p, void (*del)(void **))
{
	if (!astree_p || !*astree_p)
		return ;
	ft_astreeflush(astree_p, del);
	*astree_p = NULL;
}

int		ft_astree_addson(t_astree tree, t_astree son)
{
	if (!tree || !son)
		return (-1);
	son->fath = tree;
	if (!tree->son)
		tree->son = son;
	else
		ft_astree_addbro(son->bro, son);
	return (0);
}

int		ft_astree_addbro(t_astree tree, t_astree bro)
{
	if (!tree || !bro)
		return (-1);
	bro->fath = tree->fath;
	if (!tree->bro)
		tree->bro = bro;
	else
		ft_astree_addbro(tree->bro, bro);
	return (0);
}

