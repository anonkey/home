/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lexcmd.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/06 01:33:42 by tseguier          #+#    #+#             */
/*   Updated: 2014/03/19 01:39:10 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "ft_lexer.h"
#include "ft_cmd.h"
#include "ft_cmdtools.h"
#include "ft_word.h"
#include "libft.h"

extern char		**environ;

int		ft_lexnext_cmd(t_lexer lex, size_t wlen)
{
	char	*strcmd;
	t_cmd	cmdtmp;
	t_word	tmpw;

	if (!wlen)
		return (-1);
	strcmd = ft_strsub(lex->strin + lex->strstart, 0, wlen);
	if (!strcmd)
		return (-2);
	cmdtmp = ft_parsecmd(strcmd, &environ);
	if (!cmdtmp)
		return (-3);
	tmpw = ft_wordnew(cmdtmp, t_word_cmd);
	lex->strstart += (int)wlen;
	if (!tmpw || -1 == ft_ldcdpush_back(lex->wordlist, tmpw, S_WORD_SIZE))
		return (-4);
	lex->cmdact = cmdtmp;
	ft_strdel(&strcmd);
	return (0);
}

int		ft_lexnext_cmdarg(t_lexer lex, size_t wlen)
{
	char	*strcmd;
	t_word	tmpw;

	if (!wlen)
		return (-1);
	strcmd = ft_strsub(lex->strin + lex->strstart, 0, wlen);
	if (!strcmd)
		return (-2);
	tmpw = ft_wordnew(strcmd, t_word_cmdarg);
	if (!tmpw)
		return (-3);
	lex->strstart += (int)wlen;
	if (ft_lexadd_actword(lex, tmpw))
		return (-4);
//	if (!tmpw || -1 == ft_ldcdpush_back(lex->wordlist, tmpw, S_WORD_SIZE))
//		return (-4);
	return (0);
}

int		ft_lexnext_filename(t_lexer lex, size_t wlen)
{
	char	*strfn;
	t_word	tmpw;

	lex->filename = false;
	if (!wlen)
		return (-1);
	strfn = ft_strsub(lex->strin + lex->strstart, 0, wlen);
	if (!strfn)
		return (-2);
	tmpw = ft_wordnew(strfn, t_word_filename);
	if (!tmpw)
		return (-3);
	lex->strstart += (int)wlen;
	if (ft_lexadd_actword(lex, tmpw))
		return (-4);
//	if (!tmpw || -1 == ft_ldcdpush_back(lex->fdlist, tmpw, S_WORD_SIZE))
//		return (-4);
	return (0);
}
