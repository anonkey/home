/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_cmdtools.h                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/29 07:36:10 by tseguier          #+#    #+#             */
/*   Updated: 2014/02/06 23:09:22 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_CMDTOOLS_H
# define FT_CMDTOOLS_H
# include "ft_cmd.h"

void	ft_sigkill(int sig);

int		ft_cmdfindpath(t_cmd cmd, char **env);

int		ft_getabspath(t_cmd cmd);

t_cmd	ft_parsecmd(char *strcmd, char ***env);

void	ft_execcmd(t_cmd cmd);

#endif /* !FT_CMDTOOLS_H */

