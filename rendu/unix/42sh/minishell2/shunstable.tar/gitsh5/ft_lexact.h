/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lexact.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/07 13:28:48 by tseguier          #+#    #+#             */
/*   Updated: 2014/03/18 09:07:40 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_LEXACT_H
# define FT_LEXACT_H
# include "ft_lexer.h"
# include "ft_word.h"
# define FT_TOKFN_NB 3

typedef struct		s_lexact
{
	t_wtype		type;
	int			word_ind;
	size_t		start;
}					*t_lexact;

t_lexact	ft_lexact_get(t_lexer lex, size_t wlen);
int			ft_lexact_exec(t_lexer lex, t_lexact act);

int			ft_lexnext_sep(t_lexer lex, size_t len);
int			ft_lex_getsep(t_lexer lex, size_t len);
int			ft_lex_termsep(t_lexer lex, int sepind);
t_bool		ft_lex_issep(t_lexer lex, size_t len);

int			ft_lex_getop(t_lexer lex, size_t len);
int			ft_lexnext_op(t_lexer lex, size_t opind);
t_bool		ft_lex_isop(t_lexer lex, size_t len);

int			ft_lexnext_cmd(t_lexer lex, size_t wlen);
int			ft_lexnext_cmdarg(t_lexer lex, size_t wlen);

#endif /* !FT_LEXACT_H */
