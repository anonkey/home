/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lexact.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/07 13:25:49 by tseguier          #+#    #+#             */
/*   Updated: 2014/03/19 02:09:43 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "ft_lexer.h"
#include "ft_word.h"
#include "ft_lexact.h"

typedef int (*t_tokenize)(t_lexer , size_t );

static t_tokenize	lexfn_tab[] =
{
	NULL,
	&ft_lexnext_cmd,
	&ft_lexnext_filename,
	&ft_lexnext_cmdarg,
	&ft_lexnext_op,
	&ft_lexnext_sep//,
//	&ft_lexend
};

static t_lexact		ft_lexact_new(t_wtype type, size_t start, int wind)
{
	t_lexact	newact;

	newact = ft_memalloc(sizeof(struct s_lexact));
	if (!newact)
		return (NULL);
	newact->type = type;
	newact->start = start;
	newact->word_ind = wind;
	return (newact);
}

t_lexact			ft_lexact_get(t_lexer lex, size_t wlen)
{
	int			opind;
	int			sepind;
	t_lexact	nextact;

	if (!lex->strin[lex->strstart])
		nextact = ft_lexact_new(t_word_end, wlen, 0);
	else if (!lex->strin[lex->strstart + wlen]
			|| lex->strin[lex->strstart + wlen] == ' ')
		nextact = ft_lexact_new(t_word_cmd, wlen, 0);
	else if (-1 == (opind = ft_lex_getop(lex, wlen))
			&& (-1 == (sepind = ft_lex_getsep(lex, wlen))))
		return (NULL);
	else if (wlen > 0)
		nextact = ft_lexact_new(t_word_cmd, wlen, 0);
	else if (opind != -1)
		nextact = ft_lexact_new(t_word_op, wlen, opind);
	else //if (sepind != -1)
		nextact = ft_lexact_new(t_word_sep, wlen, sepind);
	return (nextact);
}

int					ft_lexact_exec(t_lexer lex, t_lexact act)
{
	int		err;

	if (act->type == t_word_cmd)
	{
		if (lex->filename)
			err = lexfn_tab[t_word_filename](lex, act->start);
		else if (!lex->cmdact)
			err = lexfn_tab[t_word_cmd](lex, act->start);
		else
			err = lexfn_tab[t_word_cmdarg](lex, act->start);
		return (err);
	}
	else if (act->type == t_word_end)
		return (ft_lexflush_opstack(lex));
	else if (act->type > t_word_empty)
		return (lexfn_tab[act->type](lex, act->word_ind));
	return (-1);
}

