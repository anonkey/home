/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/29 03:46:58 by tseguier          #+#    #+#             */
/*   Updated: 2014/03/17 22:27:28 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include "ft_lexer.h"
#include "ft_word.h"
#include "ft_cmd.h"
#include "ft_astree.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

void	ft_putvword(void *vword)
{
	int		i;

	i = -1;
	ft_putnbr((int)((t_word)vword)->type);
	if (((t_word)vword)->type == t_word_empty)
		ft_putendl("EMPTY_WORD");
	else if (((t_word)vword)->type == t_word_cmd)
	{
		ft_putstr("Cmd : ");
		while (((t_cmd)((t_word)vword)->content)->av[++i])
		{
			ft_putstr(((t_cmd)((t_word)vword)->content)->av[i]);
			ft_putstr(" ");
		}
		ft_putendl("");
	}
	else if (((t_word)vword)->type == t_word_filename)
	{
		ft_putstr("FD : ");
		ft_putendl((char *)((t_word)vword)->content);
	}
	else if (((t_word)vword)->type == t_word_cmdarg)
	{
		ft_putstr("Arg : ");
		ft_putendl((char *)((t_word)vword)->content);
	}
	else if (((t_word)vword)->type == t_word_op)
	{
		ft_putstr("Op : ");
		ft_putendl(((t_op *)((t_word)vword)->content)->label);
	}
	else if (((t_word)vword)->type == t_word_end)
	{
		ft_putendl((char *)((t_word)vword)->content);
	}
	else if (((t_word)vword)->type == t_word_sep)
	{
		ft_putstr("Sep : '");
		ft_putstr(((t_sep *)((t_word)vword)->content)->label);
		ft_putendl("'");
	}
	else
		ft_putendl("ERROR");
}

void	ft_putvstr(void *str)
{
	ft_putendl((char *)str);
}

int			ft_vword_priorcmp(void *vword1, void *vword2)
{
	return (ft_word_priorcmp((t_word)vword1, (t_word)vword2));
}

void		ft_fill_astree(t_astree tree, t_ldcd contentl)
{
	t_astree		treetmp;
	t_word			tmpw;

	if (!tree || ft_ldcdsize(contentl) == 0)
		return ;
	tmpw = ft_ldcdpop_back(contentl);
	if (ft_vword_priorcmp((void *)tmpw, tree->content) > 0)
	{
		ft_ldcdpush_back(contentl, tmpw, sizeof(struct s_word));
		ft_fill_astree(tree->fath, contentl);
	}
	else
	{
		treetmp = ft_astreenew(tmpw);
		if (ft_vword_priorcmp((void *)tmpw, tree->content) == 0)
			ft_astree_addbro(tree, treetmp);
		else
			ft_astree_addson(tree, treetmp);
		ft_fill_astree(treetmp, contentl);
	}
}

int		main(int argc, char **argv)
{
//	t_astree		tree;
//	t_ldcd		tmplst;
	t_lexer		lex;

	if (argc < 2)
		return (-1);
	lex = ft_lexnew(argv[1]);
	if (0 > ft_lexerize(lex))
		return (-2);
//	while (ft_ldcdsize(lex->outlist))
//	{
//		ft_putendl("");
//		ft_putnbr(ft_ldcdsize(lex->outlist));
//		ft_putendl("PROG : ");
//		tmplst = (t_ldcd)ft_ldcdpop_front(lex->outlist);
//		while (ft_ldcdsize(tmplst))
//		{
//			ft_putvword(ft_ldcdpop_back(tmplst));
//		}
//		tree = ft_astreenew(ft_wordnew(ft_strdup("End :"), t_word_end));
//		if (!tree)
//			return (-3);
//		ft_fill_astree(tree, tmplst);
//		ft_putastree(tree, &ft_putvword);
//		ft_astreedel(&tree, &ft_memdel);
//	}
//		ft_putendl("");
//	ft_putendl("LAST PROG : ");
//	while (ft_ldcdsize(lex->wordlist))
//	{
//		ft_putvword(ft_ldcdpop_back(lex->wordlist));
//	}
//	tree = ft_astreenew(ft_wordnew(ft_strdup("Start :"), t_word_end));
//	if (!tree)
//		return (-3);
//	ft_fill_astree(tree, lex->wordlist);
//	ft_putastree(tree, &ft_putvword);
//	ft_astreedel(&tree, &ft_memdel);
//		ft_putendl("");
//	ft_putendl("LAST PROG : ");
	while (ft_ldcdsize(lex->wordlist))
	{
		ft_putvword(ft_ldcdpop_back(lex->wordlist));
	}
	ft_lexdel(&lex);
	return (0);
}

