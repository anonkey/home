/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_word.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/05 03:03:15 by tseguier          #+#    #+#             */
/*   Updated: 2014/02/28 02:22:40 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_WORD_H
# define FT_WORD_H
# define S_WORD_SIZE (sizeof(struct s_word))
typedef enum	e_wtype
{
	t_word_empty,
	t_word_cmd,
	t_word_cmdarg,
	t_word_filename,
	t_word_op,
	t_word_sep,
	t_word_end
}				t_wtype;

typedef struct		s_word
{
	t_wtype		type;
	void		*content;
}					*t_word;

t_word		ft_wordnew(void *data, t_wtype type);

void		ft_worddel(t_word *word_p, void (*del)(void **));

#endif /* !FT_WORD_H */
