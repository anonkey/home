/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_builtins_exec.h                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/06 23:09:54 by tseguier          #+#    #+#             */
/*   Updated: 2014/02/06 23:09:56 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_BUILTINS_EXEC_H
# define FT_BUILTINS_EXEC_H

int		ft_builtins_get(t_cmd cmd);

int		ft_builtins_run(t_cmd cmd);

#endif /* !FT_BUILTINS_EXEC_H */

