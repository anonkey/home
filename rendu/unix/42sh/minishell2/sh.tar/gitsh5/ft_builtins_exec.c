/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_builtins_exec.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/29 14:43:22 by tseguier          #+#    #+#             */
/*   Updated: 2014/02/06 23:11:12 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <signal.h>
#include <stdlib.h>
#include "ft_builtins.h"
#include "ft_error.h"
#include "ft_cmd.h"
#include "libft.h"

void	ft_fg(char ***env)
{
	char	*fgproc;
	int		status;

	if (!env || !(fgproc = ft_getenv("FGPROC", *env)))
		ft_printerror("ft_minishell", NULL, 13, 1);
	else
	{
		kill(ft_atoi(fgproc), SIGCONT);
		waitpid(ft_atoi(fgproc), &status, WUNTRACED);
		ft_unsetenv("FGPROC", *env);
	}
}

int		ft_builtins_get(t_cmd cmd)
{
	if (!ft_strcmp(cmd->av[0], "exit")
		|| !ft_strcmp(cmd->av[0], "env")
		|| !ft_strcmp(cmd->av[0], "setenv")
		|| !ft_strcmp(cmd->av[0], "unsetenv")
		|| !ft_strcmp(cmd->av[0], "cd")
		|| !ft_strcmp(cmd->av[0], "fg"))
		return (0);
	else
		return (-1);
}

int		ft_builtins_run(t_cmd cmd)
{
	if (!ft_strcmp(cmd->av[0], "exit"))
		exit(EXIT_SUCCESS);
	else if (!ft_strcmp(cmd->av[0], "env"))
		ft_env(*(cmd->env));
	else if (!ft_strcmp(cmd->av[0], "setenv"))
	{
		if (!cmd->av[1])
			ft_env(*(cmd->env));
		else
			ft_setenv(cmd->av[1], cmd->av[2], 1, cmd->env);
	}
	else if (!ft_strcmp(cmd->av[0], "unsetenv"))
	{
		if (ft_unsetenv(cmd->av[1], *(cmd->env)) == -2)
			ft_printerror("unsetenv : Variable not found", cmd->av[0], 5, 1);
	}
	else if (!ft_strcmp(cmd->av[0], "cd"))
		ft_cd(cmd->av[1], cmd->env);
	else if (!ft_strcmp(cmd->av[0], "fg"))
		ft_fg(cmd->env);
	else
		return (-1);
	return (0);
}

