/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_word.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/05 19:56:50 by tseguier          #+#    #+#             */
/*   Updated: 2014/03/18 08:07:50 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "ft_word.h"
#include "libft.h"

t_word		ft_wordnew(void *data, t_wtype type)
{
	t_word	newword;

	newword = (t_word)ft_memalloc(S_WORD_SIZE);
	if (!newword)
		return (NULL);
	newword->type = data ? type : t_word_empty;
	newword->content = data;
	return (newword);
}

void		ft_worddel(t_word *word_p, void (*del)(void **))
{
	if (!word_p || !*word_p)
		return ;
	if (del)
	(*del)(&((*word_p)->content));
	ft_memdel((void **)word_p);
}

