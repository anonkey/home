/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_program.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/06 06:11:59 by tseguier          #+#    #+#             */
/*   Updated: 2014/02/06 06:38:21 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "ft_program.h"
#include "ft_cmd.h"
#include "libft.h"
#include "ft_word.h"

t_program	ft_prognew(t_ldcd wordlist)
{
	t_program	newprog;
	t_ldcd_cell	tail;

	if (!wordlist)
		return (NULL);
	newprog = (t_program)ft_memalloc(sizeof(struct s_program));
	newprog->wordlist = wordlist;
	tail = wordlist->tail;
	newprog->nextw = NULL;
	return (newprog);
}

void		ft_vcmddel(void **vcmd)
{
	ft_cmddel((t_cmd *)vcmd);
}

void		ft_progdel(t_program *prog_p)
{
	void (*del)(void **);

	if (!prog_p || !*prog_p)
		return ;
	while (ft_ldcdsize((*prog_p)->wordlist))
	{
		(*prog_p)->nextw = (t_word)ft_ldcdpop_back((*prog_p)->wordlist);
		del = ((*prog_p)->nextw->type == t_word_cmd) ? &ft_vcmddel : NULL;
		ft_worddel(&((*prog_p)->nextw), del);
	}
}

