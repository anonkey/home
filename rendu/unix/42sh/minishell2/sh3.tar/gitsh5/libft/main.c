/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/14 02:48:20 by tseguier          #+#    #+#             */
/*   Updated: 2014/01/17 05:40:16 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"


int		main(void)
{
	char	*a1  = ft_strdup("11111");
	char	*a2  = ft_strdup("2222222");
	char	*a3  = ft_strdup("33333333");
	char	*a4  = ft_strdup("00000000");
	char	*a5  = ft_strdup("4444444");
	char	*a6  = ft_strdup("5555");
	char	*a7  = ft_strdup("666");
	char	*a8  = ft_strdup("77777");
	char	*a9  = ft_strdup("88888");

		ft_putendl(ft_strmjoin(9, a1,a2,a3,a4,a5,a6,a7,a8,a9));
		ft_putendl(ft_strmjoin2(9, &a1,&a2,&a3,&a4,&a5,&a6,&a7,&a8,&a9));
//		ft_putendl(ft_strmjoin(9, a1,a2,a3,a4,a5,a6,a7,a8,a9));


		return (0);
}

