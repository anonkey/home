/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_astree_put.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/03 22:12:33 by tseguier          #+#    #+#             */
/*   Updated: 2014/02/07 10:44:11 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "libft.h"
#include "ft_astree.h"

void	ft_putastree_node(t_astree tree, int depth, void (*putfunc)(void *))
{
	int		i;

	i = -1;
	if (!tree)
		return ;
	while (++i < depth)
		ft_putstr("|\t");
	ft_putstr("|-> ");
	ft_putnbr(tree->flag);
	ft_putstr(" : ");
	(*putfunc)(tree->content);
	ft_putastree_node(tree->son, depth + 1, putfunc);
	ft_putastree_node(tree->bro, depth, putfunc);
}

void	ft_putastree(t_astree tree, void (*putfunc)(void *))
{
	ft_putendl("tree:");
	ft_putastree_node(tree, 0, putfunc);
}

