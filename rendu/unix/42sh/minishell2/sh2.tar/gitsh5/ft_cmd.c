/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_cmd.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/25 20:48:17 by tseguier          #+#    #+#             */
/*   Updated: 2013/12/29 19:31:40 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>
#include "libft/libft.h"
#include "ft_cmd.h"
#include "ft_cmdtools.h"

t_cmd	ft_cmdnew(char **av, char ***env)
{
	t_cmd	newcmd;

	newcmd = (t_cmd)malloc(sizeof(struct s_cmd));
	if (!newcmd)
		return (NULL);
	newcmd->av = av;
	newcmd->env = env;
	newcmd->status = 0;
	newcmd->abspath = NULL;
	return (newcmd);
}

void	ft_cmddel(t_cmd *cmd)
{
	int		i;

	i = 0;
	if ((*cmd)->av)
	{
		while ((*cmd)->av[i])
		{
			ft_strdel((*cmd)->av + i);
			++i;
		}
	}
	ft_strtabdel(&((*cmd)->av));
	(*cmd)->av = NULL;
	(*cmd)->env = NULL;
	ft_strdel(&((*cmd)->abspath));
	*cmd = NULL;
}

int		ft_cmdsetpath(t_cmd cmd, char *path)
{
	if (!access(path, X_OK))
	{
		cmd->abspath = ft_strdup(path);
		return (1);
	}
	return (0);
}

