/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_syntax.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/05 23:14:49 by tseguier          #+#    #+#             */
/*   Updated: 2014/02/07 17:41:55 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "ft_syntax.h"

/*
** Les operateurs ayant des ecriture partiellement identiques
** sont classes par ordre decroissant de longueur
*/
const t_syntax		ft_syntaxtab_sh =
{
	{
		{T_OP_LLREDIR, 2, 2, 1},
		{T_OP_LREDIR, 1, 2, 1},
		{T_OP_RRREDIR, 2, 2, 1},
		{T_OP_RREDIR, 1, 2, 1},
		{NULL, 0, 0, 0}
	},
	{
		{T_OP_PIPE, 1, 0, 1},
		{T_SEP_SEMICOL, 1, 1, 2},
		{T_SEP_NL, 1, 1, 2},
		{NULL, 0, 0, 0}
	}
};

