/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atobase.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/14 04:22:51 by tseguier          #+#    #+#             */
/*   Updated: 2014/01/14 06:08:34 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char		*ft_ctoa_base(char c, const char *basefrom, const char *baseto)
{
	char	*result;
	int		basef_i;
	int		baset_len;
	int		i;

	i = 0;
	basef_i =  ft_strchind(basefrom, c);
	if (!basefrom || !*basefrom || basef_i < 0 || !baseto || !*baseto)
		return (NULL);
	baset_len = (int)ft_strlen(baseto) - 1;
	result = ft_strnew((ft_strlen(basefrom) / baset_len) + 2);
	while (basef_i >= baset_len)
	{
		result[i] = baseto[basef_i % baset_len];
		basef_i /= baset_len;
		++i;
	}
	result[i] = baseto[basef_i];
	ft_strrev(result);
	return (result);
}

static size_t	ft_getmaxsize(char *n1, char *n2)
{
	size_t	n1len;
	size_t	n2len;

	n1len = ft_strlen(n1);
	n2len = ft_strlen(n2);
	return (((n1len > n2len) ? n1len : n2len) + 1);
}

int		ft_addcbase(char *dst, char c1, char c2, char *base, int carry)
{
	int		blen;
	int		i;

	i = carry;
	i += ft_strchind(base, c1);
	i += ft_strchind(base, c2);
	blen = (int)ft_strlen(base);
	*dst = base[i % blen];
	return ((i >= blen));
}

char		*ft_addbase(char *n1, char *n2, char *base)
{
	char	*res;
	int		carry;
	int		resi;

	resi = 0;
	res = ft_strnew(ft_getmaxsize(n1, n2));
	while (*(n1 + resi) && *(n2 + resi))
	{
		carry = ft_addcbase(res + resi, *(n1 + resi), *(n2 + resi), base, carry);
		++resi;
	}
	n1 += resi;
	n2 += resi;
	while (carry)
	{
		ft_addcbase(res + resi, *n1 ? *n1 : base[0], *n2 ? *n2 : base[0],
					base, carry);
		if (*n1)
			++n1;
		if (*n2)
			++n2;
		++resi;
	}
	if (*(n1 + resi) && !*(n2 + resi))
		ft_strcpy(res + resi, n1 + resi);
	else if (!*(n1 + resi) && *(n2 + resi))
		ft_strcpy(res + resi, n2 + resi);
	return (res);
}
/*
char		*ft_atoa_base(const char *str, const char *basefrom,
							const char *baseto)
{
	char	*result;
	char	*act;
	int		carry;
	int		baseind;
	int		i;
	int		bigger;

	i = 0;
	carry = -1;
	if (!str || !basefrom || !*basefrom || !baseto || !*baseto)
		return (NULL);
	bigger = ft_strlen(basefrom) > ft_strlen(baseto)
	while (ft_isspace(*str))
		++str;
	result = ft_strnew((ft_strlen(basefrom) / ft_strlen(baseto)) + 1)
		* ft_strlen(str);

	while (-1 < (baseind = ft_strchind(basefrom, *str)))
	{
		act = ft_ctoa_base(*str, basefrom, baseto);
		carry = (int)ft_strlen(act) - 2;
		if (carry != -1)
		{
			
		}
		*(result + i) = 
		++str;
		++i;
	}
	return (number * sign);
}
*/
