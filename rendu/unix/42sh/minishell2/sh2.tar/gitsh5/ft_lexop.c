/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lexop.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/29 08:43:13 by tseguier          #+#    #+#             */
/*   Updated: 2014/02/07 17:54:02 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "libft.h"
#include "ft_lexer.h"
#include "ft_syntax.h"

int		ft_lex_getop(t_lexer lex, size_t len)
{
	int		i;
	char	*start;
	t_op	*opstr;

	i = 0;
	start = lex->strin + lex->strstart + (long)len;
	while (i < NB_OPSTR)
	{
		opstr = &(lex->syntax.opdict[i]);
		if (!strncmp(opstr->label, start, opstr->len))
			return (i);
		++i;
	}
	return (-1);
}

t_bool		ft_lex_isop(t_lexer lex, size_t len)
{
	return ((0 <= ft_lex_getop(lex, len)) ? true : false);
}

int		ft_lexnext_op(t_lexer lex, int opind)
{
	t_word		opw;

	if (!lex || opind >= NB_OPSTR || opind < 0)
		return (-1);
	opw = ft_wordnew((void *)&(lex->syntax.opdict[opind]), t_word_op);
	if (!opw)
		return (-2);
	if (lex->syntax.opdict[opind].prior == 1)
		lex->filename = true;
	lex->strstart += ft_strlen(lex->syntax.opdict[opind].label);
	if (ft_lexadd_actword(lex, opw))
		return (-3);
	return (0);
}

int		ft_lexflush_opstack(t_lexer lex)
{
	t_word		tmpw;

	while (ft_ldcdsize(lex->opstack))
	{
		tmpw = (t_word)ft_ldcdpop_back(lex->opstack);
		if (!tmpw || (-1 == ft_ldcdpush_back(lex->wordlist, tmpw, S_WORD_SIZE)))
			return (-1);
	}
	ft_ldcdpush_back(lex->wordlist, ft_wordnew(&(lex->syntax.sepdict[1]), t_word_sep), sizeof(struct s_word));
	return (0);
}

