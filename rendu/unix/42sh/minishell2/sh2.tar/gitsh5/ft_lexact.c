/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lexact.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/07 13:25:49 by tseguier          #+#    #+#             */
/*   Updated: 2014/02/28 01:21:40 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "ft_lexer.h"
#include "ft_word.h"
#include "ft_lexact.h"

typedef int (*t_tokenize)(t_lexer , t_lexact );

static t_lexact		ft_lexact_new(t_wtype type, size_t start, int wind)
{
	t_lexact	newact;

	newact = ft_memalloc(sizeof(struct s_lexact));
	if (!newact)
		return (NULL);
	newact->type = type;
	newact->start = start;
	newact->word_ind = wind;
	return (newact);
}

t_lexact			ft_lexact_get(t_lexer lex, size_t wlen)
{
	int			opind;
	int			sepind;
	t_lexact	nextact;

	if (!lex->strin[lex->strstart])
		nextact = ft_lexact_new(t_word_end, wlen, 0);
	else if (!lex->strin[lex->strstart + wlen]
			|| lex->strin[lex->strstart + wlen] == ' ')
		nextact = ft_lexact_new(t_word_cmd, wlen, 0);
	else if (-1 == (opind = ft_lex_getop(lex, wlen))
			&& (-1 == (sepind = ft_lex_getsep(lex, wlen))))
		return (NULL);
	else if (wlen > 0)
		nextact = ft_lexact_new(t_word_cmd, wlen, 0);
	else if (opind != -1)
		nextact = ft_lexact_new(t_word_op, wlen, opind);
	else //if (sepind != -1)
		nextact = ft_lexact_new(t_word_sep, wlen, sepind);
	return (nextact);
}

int					ft_lexact_exec(t_lexer lex, t_lexact act)
{
	int		err;

	if (act->type == t_word_cmd)
	{
		if (lex->filename)
			err = ft_lexnext_filename(lex, act->start);
		else if (!lex->cmdact)
			err = ft_lexnext_cmd(lex, act->start);
		else
			err = ft_lexnext_cmdarg(lex, act->start);
		return (err);
	}
	else if (act->type == t_word_op)
		return (ft_lexnext_op(lex, act->word_ind));
	else if (act->type == t_word_sep)
		return (ft_lexnext_sep(lex, act->word_ind));
	else if (act->type == t_word_end)
		return (ft_lexflush_opstack(lex));
	return (-1);
}

