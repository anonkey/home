/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lexer.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseguier <tseguier@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/29 08:42:14 by tseguier          #+#    #+#             */
/*   Updated: 2014/03/17 23:05:03 by tseguier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "libft.h"
#include "ft_syntax.h"
#include "ft_word.h"
#include "ft_lexer.h"
#include "ft_lexact.h"


int			ft_lexerize(t_lexer lex)
{
	size_t		wlen;
	t_lexact	act;
	int			err;

	while (!act || act->type != t_word_end)
	{
		while (lex->strin[lex->strstart] == T_SEP_CHAR)
			++lex->strstart;
		act = NULL;
		wlen = 0;
		while (!(act = ft_lexact_get(lex, wlen)))
			++wlen;
		if (act->type == t_word_empty)
			return (-1);
		if (0 > (err = ft_lexact_exec(lex, act)))
			return (err);
	}
	return (0);
}

int		ft_word_priorcmp(t_word w1, t_word w2)
{
	if (w1->type != w2->type)
		return ((int)w1->type - (int)w2->type);
	if (w1->type == t_word_op)
		return (((t_op*)(w1->content))->prior - ((t_op*)(w2->content))->prior);
	return (((t_sep *)(w1->content))->prior - ((t_sep *)(w2->content))->prior);
}

int			ft_lexadd_actword(t_lexer lex, t_word actw)
{
	t_word		tmpw;

	while (ft_ldcdsize(lex->opstack)
			&& (tmpw = (t_word)lex->opstack->tail->content)
			&& (0 <= ft_word_priorcmp(actw, tmpw)))
	{
		tmpw = (t_word)ft_ldcdpop_back(lex->opstack);
		if (!tmpw || (-1 == ft_ldcdpush_back(lex->wordlist, tmpw, S_WORD_SIZE)))
			return (-2);
	}
	if (-1 == ft_ldcdpush_back(lex->opstack, actw, S_WORD_SIZE))
		return (-3);
	return (0);
}

t_lexer		ft_lexnew(char *strin)
{
	t_lexer		newlex;

	newlex = (t_lexer)ft_memalloc(sizeof(struct s_lexer));
	if (!newlex)
		return (NULL);
	newlex->strin = strin;
	newlex->cmdact = NULL;
	newlex->filename = false;
	newlex->wordlist = ft_ldcdnew();
	newlex->opstack = ft_ldcdnew();
	newlex->fdlist = ft_ldcdnew();
	newlex->syntax = T_SYNTAXTAB_CUR;
	newlex->status = 0;
	return (newlex);
}

void	ft_lexdel(t_lexer *lex_p)
{
	ft_ldcddel(&((*lex_p)->opstack), &ft_memdel);
	ft_ldcddel(&((*lex_p)->wordlist), &ft_memdel);
	ft_memdel((void **)lex_p);
}


